# modmaker.lua ChangeLog

### Version 0.80
- Added modmaker.lua library