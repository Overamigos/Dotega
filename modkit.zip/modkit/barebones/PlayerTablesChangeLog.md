# playertables.lua ChangeLog

### Version 0.90
- Added playertables.lua library