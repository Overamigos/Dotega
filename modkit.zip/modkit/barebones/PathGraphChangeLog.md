# pathgraph.lua ChangeLog

### Version 0.80
- Added pathgraph.lua library